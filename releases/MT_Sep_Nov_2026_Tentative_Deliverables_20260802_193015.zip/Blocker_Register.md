# Blocker Register — MT Dashboard Sep–Nov 2026 Tentative Forecast
**Last updated:** 2026-08-02  
**Release status:** TENTATIVE – QUANTITY PLANNING TECHNICALLY READY  
**Release gate:** Quantity planning technically complete. Finance and Sales sign-off still required before this becomes FINAL.

---

## B-001 · TOT Double-Counting in NSV Bridge

| Field | Value |
|---|---|
| **Blocker ID** | B-001 |
| **Status** | PARTIALLY RESOLVED — TENTATIVE BASIS CONFIRMED |
| **Severity** | P1 (was P0) |
| **Finance Gate** | FIN-GATE-TOT-001: **WARNING** (Tentative mode) / **BLOCKED** (Final Financial mode) |
| **Resolution date** | PENDING Finance formal sign-off |

### Evidence confirming Scenario A (post-TOT NSV, no double deduction)
- `PowerBI/DAX/13_CM2_Measures.dax`: *"NSV here is [Total Primary Article NSV] from DAX/12_TOT_Measures.dax (already net of TOT%/on-invoice-margin-pass-on and tax), **so no further deduction happens in this file**."*
- `config/cm2_formula.csv` (commit `fc45de46`): *"Already net of TOT%/on-invoice margin pass-on… **Do not deduct TOT again**."*
- `PowerBI/DAX/12_TOT_Measures.dax`: TOT pass-on = MRP × Avg_TOT → NSV = MRP − TOT_pass-on − Tax (post-TOT by construction)
- Data: 100% of PRIMARY_INVOICE_HISTORY rows show effective (implied) TOT > stored TOT (median implied ~72%, stored median ~41%)

### Tentative base case: Scenario A
- **CM2 = Invoice NSV − Approved Expenses** (no trade-spend line)
- No second TOT deduction applied
- `mrp_fountain_enrichment.py::run_finance_gate_tot()` updated: `mode="TENTATIVE"` → WARNING (never BLOCKED)
- `mode="FINAL_FINANCIAL"` → BLOCKED until Finance formal confirmation

### Open investigation (not blocking tentative)
Why does implied TOT (72%) diverge from stored TOT (41%)? Hypothesis: stored TOT is chain discount only; invoice NSV already reflects full trade pass-on (rebates, listing fees, promo). Finance to confirm full TOT definition.

### Scenario B (sensitivity only)
Documented in `B001_TOT_Component_Analysis.xlsx` and `FIN_GATE_TOT_001_Decision_Pack.xlsx`. Not the operational basis.

### Required to close B-001
Finance to provide written confirmation of NSV basis (pre-TOT or post-TOT) and full TOT component definition.

---

## B-002 · All_Expenses_together.xlsx Not Found

| Field | Value |
|---|---|
| **Blocker ID** | B-002 |
| **Status** | WORKBOOK NOT FOUND — Q1 FY27 ACTUALS PARTIALLY RECOVERED FROM GIT HISTORY |
| **Severity** | P1 |
| **Search outcome** | Exhaustive search of 16 locations — file absent everywhere |

### Search locations checked (see B002_Expense_Source_Search_Report.xlsx)
1. Current branch working tree — NOT FOUND  
2. `main` branch — NOT FOUND  
3. All remote branches (`git branch -r`) — NOT FOUND  
4. `git stash list` — empty  
5. `git lfs ls-files` — no LFS objects  
6. `PowerBI/RawDataFolders/` — no xlsx files  
7. `PowerBI/SeedData/` — only example rows in `PL_Expense_Input.csv`  
8. `margin_repository/`, `forecast_engine/` — no expense source files  
9. `Phase_A_Input/` — no expense files  
10–16. All other project folders — NOT FOUND

### Partial recovery
**Source:** `config/cm2_expense_taxonomy.csv` (git commit `fc45de46`, 2026-07-24)  
**Q1 FY27 actuals extracted (all PENDING APPROVAL):**

| Expense Head | Q1 FY27 (₹ L) | Monthly Avg (₹ L) | Risk |
|---|---|---|---|
| Indirect Claim Base (excl. GST) | 818.45 | 272.82 | MEDIUM |
| Indirect Claim GST | 122.36 | 40.79 | EXCLUDE |
| Balance Provision | 1,034.01 | — | EXCLUDED (carry-forward) |
| BA CTC | 368.99 | 123.00 | MEDIUM |
| Supervisor CTC (MT+Hybrid+GT) | 44.46 | 14.82 | HIGH (channel split unknown) |
| Merchandiser CTC (D-Mart) | 279.49 | 93.16 | LOW |

### Critical data still missing
- `MT_Spend.xlsx` — never committed to git; payroll source
- `MTIndirect_Claim_April_26_to_June_26.xlsb` — never committed; claims ledger  
- COGS — no source file supplied  
- Visibility/Rental/Trade Schemes — only example rows in PL_Expense_Input.csv  
- BA Incentive — triple-count risk; Finance dedup decision required

### Required to close B-002
Finance to supply: `MT_Spend.xlsx`, `MTIndirect_Claim .xlsb`, and `All_Expenses_together.xlsx` (or equivalent) with authorised sign-off. See `B002_Expense_Source_Search_Report.xlsx` for full search log.

---

## B-003 · Fountain MRP Enrichment — Pending Denominations (RESOLVED)

| Field | Value |
|---|---|
| **Blocker ID** | B-003 |
| **Status** | RESOLVED — ENRICHMENT COMPLETE |
| **Rows resolved** | 1,056 margin rows (862 PACK_CASE_LEVEL_MRP + 194 AGGREGATE_DENOMINATION) |
| **Forecast rows** | 3,126 rows (1,056 × 3 months) |

### Resolution
All 1,056 pending rows matched to Fountain consumer-unit MRP via EAN lookup:
- 862 PACK_CASE_LEVEL_MRP rows → HIGH confidence match
- 194 AGGREGATE_DENOMINATION rows → MEDIUM confidence match
- 0 unmatched rows

Reconciliation: 1,056 margin rows × 3 months = 3,168 expected; 42 delta = 14 VMM-excluded rows/month × 3 = confirmed.

**Constraint applied:** Fountain MRP is substituted directly as consumer-unit MRP. No division by pack size, gram count, or unit count applied.

---

## Open Governance Items

| ID | Item | Status | Owner |
|---|---|---|---|
| ALLOC-000 | Retain Unallocated (safe default) | APPROVED | Project default |
| ALLOC-001 | Direct Chain + Brand tagging | DRAFT | Finance |
| ALLOC-002 | Retain at Chain Level | DRAFT | Finance |
| ALLOC-003 | Retain at Brand Level | DRAFT | Finance |
| ALLOC-004 | Employee → Chain crosswalk | DRAFT (BLOCKER: 16 non-chain tokens) | Finance |
| ALLOC-005 | Employee → Zone (shared) | DRAFT (BLOCKER: MT channel split) | Finance |
| ALLOC-006 | Store Universe Driver | DRAFT | Finance |
| ALLOC-007 | NSV Contribution Share | BLOCKED (must not be used) | Finance |
| ALLOC-008 | Distributor → Chain crosswalk | BLOCKED (no crosswalk exists) | Finance |

---

## Release Status Hierarchy

| Status | Condition | Current? |
|---|---|---|
| TENTATIVE – QUANTITY PLANNING TECHNICALLY READY | Forecast qty computed; no Sales/Finance sign-off | **YES** |
| FINAL – QUANTITY PLANNING APPROVED WITH TENTATIVE FINANCIAL SCENARIOS | Sales approves qty; Finance reviews scenarios | NO |
| FINAL – BUSINESS AND FINANCIAL USE APPROVED | All Finance gates cleared; CM2 Finance-approved | NO |

**Do not state that the quantity plan is "business approved" unless an authorised business reviewer, reviewer date, and approval evidence exist.**
