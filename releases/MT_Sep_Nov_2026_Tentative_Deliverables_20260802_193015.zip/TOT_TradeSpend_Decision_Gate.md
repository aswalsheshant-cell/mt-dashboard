# TOT Trade-Spend Decision Gate — FIN-GATE-TOT-001
**Generated:** 02 Aug 2026  
**Status:** ⛔ BLOCKED — FINAL FINANCIAL mode is locked until this gate is resolved.

---

## Finding

The forecast engine computes:
```
trade_spend_per_unit = unit_nsv × stored_TOT%
```

For `VALIDATED_NSV:PRIMARY_INVOICE_HISTORY` rows, `unit_nsv` is the **actual primary invoice price**
— the price at which Honasa/Mamaearth invoices its distributor. This price already incorporates
the full negotiated trade terms for that chain.

Applying `stored_TOT%` to this already-discounted price **deducts trade a second time**
in any Finance CM2 bridge that computes `CM2 = NSV − Trade_Spend − Costs`.

---

## Evidence

| Metric | Value |
|---|---|
| Rows analysed (PRIMARY_INVOICE_HISTORY) | 955 |
| Rows with double-count signal | 955 (100.0%) |
| Median effective TOT (from invoice) | 72.14% |
| Median stored TOT (margin repo) | 40.68% |
| Median delta per unit (trade_A − trade_B) | ₹-53.97 |

The effective TOT implied by primary invoice prices (**72.14%**) is
substantially higher than the stored TOT (**40.68%**) on **100% of
primary invoice rows**. This confirms that the invoice price already reflects total trade
at the actual (higher) rate, not just the stored rate.

---

## Scenario Comparison

### Scenario A — Current Behaviour (DOUBLE-COUNT RISK)
```
unit_nsv     = primary_invoice_price  (post-trade, actual)
trade_spend  = unit_nsv × stored_TOT%
```
**Risk:** `unit_nsv` already has trade deducted at effective TOT (~72.14%).
Applying stored TOT (40.68%) again in the CM2 bridge deducts trade twice.

### Scenario B — Corrected (SINGLE-COUNT)
```
gross_nsv    = MRP / (1 + GST%)
unit_nsv     = gross_nsv / (1 + stored_TOT%)   [= formula NSV]
trade_spend  = gross_nsv × stored_TOT%
```
**Note:** Uses stored TOT, not effective TOT. Gross NSV minus trade = formula NSV.
Consistent internally, but the resulting NSV is **higher** than actual invoice prices
because stored TOT < effective TOT for all primary invoice rows.

### Scenario C — Ideal (Finance approval required)
```
gross_nsv    = MRP / (1 + GST%)
unit_nsv     = primary_invoice_price  (actual net revenue received)
trade_spend  = gross_nsv − unit_nsv   [= actual trade deducted]
```
This is the Finance-correct view. It requires Finance to confirm that:
1. Primary invoice prices are gross-of-GST, net-of-all-trade.
2. The margin repository stores the correct GST rate per EAN.
3. MRP values are consumer-facing (not case/aggregate) — which Fountain enrichment now provides.

---

## Required Actions

| # | Action | Owner | Deadline |
|---|---|---|---|
| 1 | Finance to confirm: is `unit_nsv_validated` pre-trade or post-trade? | Finance Controller | ASAP |
| 2 | If post-trade: update forecast engine to use Scenario C logic | Sales Analytics | After #1 |
| 3 | If stored TOT% is wrong: update margin repo TOT% to effective rates | Sales Analytics | After #1 |
| 4 | Re-run forecast in FINAL mode after gate resolution | Demand Planning | After #2/#3 |

---

## Impact on Current Outputs

| Output | Status |
|---|---|
| Forecast Qty (Sep–Nov 2026) | ✅ NOT AFFECTED — quantity planning is independent of NSV |
| Forecast NSV (existing) | ⚠️ Tentative — use Scenario A values with caution |
| Trade Spend | ⛔ OVERSTATED in CM2 bridge if invoice NSV is post-trade |
| CM2 | ⛔ UNDERSTATED if trade double-counted in CM2 bridge |
| Fountain Proposed NSV | ⚠️ Tentative — Finance approval required |

---

## Blocker Register Entry

```
Gate ID:    FIN-GATE-TOT-001
Status:     OPEN
Raised:     02 Aug 2026
Owner:      Finance Controller
Symptom:    100% of PRIMARY_INVOICE_HISTORY rows show effective TOT > stored TOT.
            trade_spend = unit_nsv × stored_TOT double-counts when NSV is already post-trade.
Resolution: Finance must confirm NSV basis and approve Scenario A, B, or C.
Unblocks:   FINAL FINANCIAL mode, Finance-approved CM2, trade spend reporting.
```

---

*This gate was raised automatically by `margin_repository/mrp_fountain_enrichment.py`.  
All financial figures are TENTATIVE until FIN-GATE-TOT-001 is resolved.*
