# Demand Forecast Report — 02 Aug 2026

## Executive Summary

- **Forecast Rows**: 9138
- **Articles**: 951
- **Chains**: 26
- **Forecast Months**: 3

### Key Metrics

- **Total Forecast Qty**: 7,444,964 units
- **Total Forecast NSV**: ₹120,230,566
- **Total Trade Spend**: ₹52,630,058
- **Total CM2**: ₹37,013,121
- **Avg Confidence**: 73.0%

### Risk Summary

- **Articles at Risk (HIGH_RISK/BLOCKED)**: 2799
- **Exception Count**: 2799

## Scenario Comparison


### Expected
- **Qty**: 7,444,964 units
- **NSV**: ₹120,230,566
- **CM2**: ₹67,600,509

### Best Case
- **Qty**: 8,933,957 units
- **NSV**: ₹144,276,680
- **CM2**: ₹108,705,793

### Worst Case
- **Qty**: 5,583,723 units
- **NSV**: ₹90,172,925
- **CM2**: ₹17,999,563


## Data Quality

- **Avg Confidence %**: 73.0%
- **High Risk Count**: 2799
- **Exception Count**: 2799

## Top Growth Drivers

- Glow+ Dewy Sunscreen 50gm: 0.0% YoY
- Radiance+ Dewy Sunscreen 50gm: 0.0% YoY
- 100% Natural Berry Blast Toothpaste for Kids 50gm: 0.0% YoY
- Aloe Turmeric Gel for Skin & Hair 150ml: 0.0% YoY
- Aloe Vera Face Wash 100 ml: 0.0% YoY


_Forecast generated 02 Aug 2026. See Forecast_Summary.json for full details._
