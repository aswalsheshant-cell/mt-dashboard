# Final Acceptance Report — Sep–Nov 2026 Tentative Forecast
**Date:** 2026-08-02  
**Branch:** `claude/store-master-qc-duplicates-4pvmmk`  
**Release status:** TENTATIVE – QUANTITY PLANNING TECHNICALLY READY

---

## 1. Scope

Resolution of B-001 (TOT double-counting), B-002 (expense source search), Fountain MRP enrichment of 3,126 pending forecast rows, NSV reasonableness testing, CM2 provisional scenarios, and all 13 required deliverable files.

---

## 2. Deliverables Status

| # | File | Status | Notes |
|---|---|---|---|
| 1 | `B001_TOT_Component_Analysis.xlsx` | COMPLETE | Top-20 EAN Scenario A/B comparison, chain summary, population statistics |
| 2 | `FIN_GATE_TOT_001_Decision_Pack.xlsx` | COMPLETE | Gate updated to WARNING (Tentative) / BLOCKED (Final Financial) |
| 3 | `B002_Expense_Source_Search_Report.xlsx` | COMPLETE | 16 search locations documented |
| 4 | `Recovered_Expense_Data_QC.xlsx` | COMPLETE | Q1 FY27 actuals extracted from git history; all PENDING APPROVAL |
| 5 | `CM2_Provisional_Assumptions.csv` | COMPLETE | 21 fields, 8 expense heads, all approval_status = PENDING |
| 6 | `Expense_Allocation_Reconciliation.xlsx` | COMPLETE | All heads mapped to allocation rules; blockers documented |
| 7 | `Expense_Overlap_Report.xlsx` | COMPLETE | 9 overlap/double-count risks catalogued |
| 8 | `Tentative_CM2_Low_Base_High.xlsx` | COMPLETE | Rebuilt with Q1 FY27 actuals (not web estimates); 5-measure structure |
| 9 | `NSV_Reasonableness_Report.xlsx` | COMPLETE | WARNING overall; 2.16x YoY attributed to coverage expansion |
| 10 | `Forecast_Planning_Workbook.xlsx` | EXISTING (not modified — India format sheet from prior session) | |
| 11 | `Blocker_Register.md` | UPDATED | B-001 partially resolved, B-002 search complete, B-003 resolved |
| 12 | `Final_Acceptance_Report.md` | THIS FILE | |
| 13 | `margin_repository/mrp_fountain_enrichment.py` | UPDATED | TOT gate mode parameter added |

---

## 3. B-001 Resolution

**Status: PARTIALLY RESOLVED — TENTATIVE BASIS CONFIRMED**

Scenario A (NSV is post-TOT, no second deduction in CM2) confirmed as the Finance-aligned tentative basis via:
- DAX `13_CM2_Measures.dax`: explicit "no further deduction happens"
- `cm2_formula.csv`: explicit "Do not deduct TOT again"
- `12_TOT_Measures.dax`: TOT pass-on = MRP × Avg_TOT (deducted before NSV)

FIN-GATE-TOT-001 updated:
- Tentative mode → **WARNING** (not BLOCKED); Scenario A is tentative base
- Final Financial mode → **BLOCKED** until Finance formal sign-off

Open: why implied TOT (72%) > stored TOT (41%)? Not blocking tentative. Finance to clarify.

---

## 4. B-002 Resolution

**Status: WORKBOOK NOT FOUND — PARTIAL RECOVERY**

`All_Expenses_together.xlsx` is absent from all git history, branches, stash, LFS, and related folders (16 locations searched). Source files `MT_Spend.xlsx` and `MTIndirect_Claim_April_26_to_June_26.xlsb` were also never committed.

Q1 FY27 actuals recovered from `cm2_expense_taxonomy.csv` (commit `fc45de46`):
- Claims base: ₹818.45 L (Q1) / ₹272.82 L/month (PROVISIONAL)
- BA CTC: ₹368.99 L (Q1) / ₹123.00 L/month
- Supervisor CTC: ₹44.46 L (Q1) / ₹14.82 L/month (MT share unknown)
- Merchandiser CTC: ₹279.49 L (Q1) / ₹93.16 L/month (D-Mart implicit)

All amounts: **PENDING APPROVAL** — not confirmed by Finance.

---

## 5. NSV Reasonableness

**Status: WARNING**

- Sep–Nov 2026 proposed NSV: **₹177.40 Cr** (3 months, ₹59.13 Cr/month)
- Prior year Sep–Nov 2025 NSV: ₹82.25 Cr → YoY factor **2.16x**
- L3M (Feb–Apr 2026) monthly avg: ₹36.32 Cr → factor **1.63x**
- May 2026 (latest): ₹44.16 Cr → forecast is **1.34x May**

The 2.16x YoY jump is **a coverage expansion artefact**, not validated organic growth:
- Before Fountain enrichment: ₹12.02 Cr (validated NSV rows only)
- After Fountain enrichment: ₹177.40 Cr (all rows including 3,126 previously ₹0)
- The ₹165.38 Cr Fountain-proposed NSV was ₹0 in all prior forecasts

Finance and Sales must confirm Sep–Nov 2026 NSV target before this figure is used for financial planning.

---

## 6. Fountain MRP Enrichment (B-003 — RESOLVED)

| Metric | Value |
|---|---|
| Pending margin rows resolved | 1,056 (862 PACK_CASE + 194 AGGREGATE) |
| Pending forecast rows resolved | 3,126 |
| Match rate | 100% (1,056/1,056) |
| HIGH confidence | 862 rows |
| MEDIUM confidence | 194 rows |
| Pack-size division applied | NONE — Fountain MRP is consumer-unit price directly |
| VMM exclusions | 14 EAN×Chain combos × 3 months = 42 rows (operational_inclusion_flag=False) |

---

## 7. Test Results

| Test | Result |
|---|---|
| `python -m py_compile margin_repository/mrp_fountain_enrichment.py` | PASS |
| Enrichment: 1,056 pending rows matched | PASS |
| Fountain match rate 100% | PASS |
| No pack-size division applied | PASS — constraint in `classify_mrp()` |
| VMM exclusions: 14/month | PASS — confirmed by set-difference analysis |
| B-003 reconciliation: 3,126 = 1,056×3 − 42 VMM | PASS |
| TEST-TOT-001: implied_tot_pct > 0 for all primary rows | PASS |
| TEST-TOT-002: No second TOT deduction in CM2 path | PASS — DAX confirmed |
| Gate verdict in TENTATIVE mode | PASS — WARNING (not BLOCKED) |
| Gate verdict in FINAL_FINANCIAL mode | PASS — BLOCKED |
| Excluded brands (Pure Origin, Lumineve, Staze) | PASS — absent from all forecast rows |
| CM2_Provisional_Assumptions.csv: 21 fields | PASS |
| All expense assumptions: approval_status = PENDING | PASS |
| Balance Provision excluded | PASS |
| TOT excluded from CM2 | PASS |
| Claim GST excluded | PASS |
| No dummy data | PASS — all values from actual git history; blanks where data absent |
| No mixing of tentative/final | PASS — all outputs labelled TENTATIVE |

---

## 8. Non-Negotiable Constraints Verification

| Constraint | Verified |
|---|---|
| No fabricated actual or approved business data | YES |
| No silent replacement of source values | YES |
| No deletion of unresolved records (VMM preserved as gross_forecast_qty) | YES |
| Assumptions not marked as approved | YES — all PENDING |
| Tentative and final figures not mixed without clear labels | YES |
| Pure Origin, Lumineve, Staze excluded from forecasts | YES |
| No automatic pack-size division | YES |
| Release status: "TENTATIVE – QUANTITY PLANNING TECHNICALLY READY" | YES |

---

## 9. Remaining Blockers for Finance Sign-Off

| Decision | Required for |
|---|---|
| D1: CM2 definition (gross-of-COGS vs post-COGS) | COGS inclusion |
| D2: Approve indirect claims (Final Status for 58 rows) | Claims in CM2 |
| D3: BA CTC chain crosswalk (16 non-chain tokens) | ALLOC-004 |
| D4: MT-only Supervisor share (channel split) | ALLOC-005 |
| D5: BA Incentive dedup (authoritative payout row) | OVL-005 |
| D6: D-Mart chain confirmation for Merchandiser | ALLOC-004 |
| D7: Actual Visibility/Rental/Trade Scheme data | OVL-008, OVL-009 |
| D8: Distributor-to-chain crosswalk | ALLOC-008 |
| D9: Sep-Nov 2026 NSV target confirmation | NSV reasonableness PASS |
| D10: Formal NSV basis sign-off (post-TOT) | B-001 FINAL closure |
