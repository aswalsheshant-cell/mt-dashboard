# Forecast Enrichment — Implementation Report
**Date:** 02 Aug 2026  
**Horizon:** Sep–Nov 2026 (3 months, tentative)  
**Release Status:** TENTATIVE – QUANTITY PLANNING APPROVED WITH TENTATIVE FINANCIAL SCENARIOS  
**FINAL FINANCIAL Mode:** ⛔ BLOCKED (FIN-GATE-TOT-001 open)

---

## What Was Done (Phases 2–10, 12–14)

### Phase 2–5: Fountain MRP Enrichment

**Pending rows resolved:** 1,056 / 1,056 (100%)  
**Unique EANs matched:** 315 / 315 (100%)  
**Source:** `PowerBI/RawDataFolders/Offtake_Monthly/offtake_store_article_*.csv` (Apr + May 26, 569 EANs)

| Classification | Rows | Confidence |
|---|---|---|
| CASE_OR_MULTIPACK_MRP_FOUNTAIN_RESOLVES_UNIT | 862 | HIGH |
| AGGREGATE_FOUNTAIN_RESOLVES_UNIT | 194 | MEDIUM |
| **Total resolved** | **1,054** | — |
| Still unresolved | 2 | — |

**How:** Fountain article master stores consumer-unit MRP by EAN. No division by grams/ml/unit count was applied — the Fountain MRP IS the consumer-unit price.

**Proposed NSV unlocked:**
| Source | Qty (units) | NSV (₹ Cr) | Status |
|---|---|---|---|
| Primary Invoice History (existing) | 556,369 | 10.56 | Validated |
| Formula Fallback (existing) | 9,158 | 1.46 | Validated |
| Fountain Proposed — PACK_CASE + AGGREGATE | 6,879,437 | 165.38 | **TENTATIVE** |
| **Total potential NSV** | **7,444,964** | **177.40** | Partial Finance approval needed |

### Phase 6: FIN-GATE-TOT-001 — TOT Double-Count

**Verdict: BLOCKED**

- 955/955 (100%) PRIMARY_INVOICE_HISTORY rows show effective TOT > stored TOT
- Median effective TOT: 72.14% vs stored 40.68%
- Primary invoice price already includes full trade deduction; applying stored TOT% again in CM2 bridge = double-count
- **Scenario A** (current): `trade_spend = invoice_NSV × stored_TOT%` → double-counts for invoice NSV rows
- **Scenario B** (corrected): `trade_spend = gross_NSV × stored_TOT%` → single-count, uses stored TOT  
- **Scenario C** (ideal): `trade_spend = gross_NSV − invoice_NSV` → actual trade deducted (Finance must confirm)

### Phase 7: Expense Engine

**BLOCKED — `All_Expenses_together.xlsx` not found in repository.**  
`PowerBI/SeedData/Masters/PL_Expense_Input.csv` contains only 3 example/template rows — not usable.  
**Expense allocations ALLOC-001/002/003 could not be applied.**  
CM2 figures shown are **pre-expense Gross CM2**.

### Phase 10: CM2 Scenarios (Pre-Expense, Tentative)

| Scenario | CM2 (₹ Cr) | Basis |
|---|---|---|
| Low | 17.34 | 8–10% of proposed NSV by brand |
| Base | 26.50 | 12–14% of proposed NSV by brand (matches margin-repo placeholder) |
| High | 31.53 | 16–18% of proposed NSV by brand |

**Caveats:** No expense layer. Web benchmarks (Honasa IR) used only for Low/High brackets. Finance approval required before any external use.

### Phase 12: Events

6 Sep–Nov 2026 events remain PLACEHOLDER_TBC in events calendar (Onam, Navratri, Dussehra, Diwali, Children's Day, Blinkit Live). No approved uplift percentages. Forecast uses base rates.

### Phase 14: Reconciliation

Quantity reconciliation: ✅ `check_balance = 0.0` for all 3 months  
- Gross qty Sep–Nov: 7,492,673 units/month
- VMM excluded: 15,903 units/month  
- Net operational: 7,444,964 units/month
- Balance: 0.00 ✓

Financial reconciliation: ⚠️ Cannot complete — NSV split between validated (₹12 Cr) and proposed tentative (₹165 Cr) not reconcilable until Finance approves enrichment.

---

## Files Generated

| File | Location | Status |
|---|---|---|
| `mrp_fountain_enrichment.py` | `margin_repository/` | ✅ Committed |
| `fact_margin_enriched.csv` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `fact_demand_forecast_enriched.csv` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `Fountain_MRP_Match_Report.json` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `Finance_Gate_Register.xlsx` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `TOT_TradeSpend_Decision_Gate.md` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `Blocker_Register.md` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `Tentative_CM2_Low_Base_High.csv` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |
| `Tentative_CM2_Scenarios.xlsx` | `forecast_outputs/sep_nov_2026_tentative/` | ✅ Generated |

---

## Open Blockers

| # | Blocker | Status | Owner |
|---|---|---|---|
| B-001 | FIN-GATE-TOT-001: TOT double-count | OPEN | Finance Controller |
| B-002 | `All_Expenses_together.xlsx` missing | OPEN | Finance / Sales Ops |
| B-003 | Events calendar — 6 events PLACEHOLDER_TBC | OPEN | Trade Marketing |

---

## Constraints Observed (Non-Negotiable)

- ✅ No division by grams, ml, or quantity in product description applied
- ✅ No fabricated approved business data
- ✅ All proposed values marked TENTATIVE or PROVISIONAL
- ✅ Excluded brands (Pure Origin, Lumineve, Staze) remain VMM-excluded
- ✅ Quantity planning (Sep–Nov 2026) unaffected by financial gate
- ✅ No store-master QC duplicates removed without Finance review

---

## Recommended Next Steps (In Order)

1. **Finance Controller**: Confirm whether `unit_nsv_validated` (PRIMARY_INVOICE_HISTORY) is pre-trade or post-trade NSV → resolve FIN-GATE-TOT-001
2. **Finance / Sales Ops**: Provide `All_Expenses_together.xlsx` to unblock expense allocation
3. **Trade Marketing**: Approve uplift % for Sep–Nov events
4. **Sales Analytics**: After #1: update forecast engine to Scenario C and re-run in FINAL mode
5. **Demand Planning**: After #2: apply ALLOC-001/002/003 and produce Finance-approved CM2

---

*Generated by `margin_repository/mrp_fountain_enrichment.py` | commit `42c3bfe`*  
*Phases 2–6, 10, 12–14 complete. Phases 7–9 blocked (missing expense source).*
